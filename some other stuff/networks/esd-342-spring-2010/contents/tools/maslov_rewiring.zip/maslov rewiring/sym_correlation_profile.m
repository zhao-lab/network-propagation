%sym_correlation_profile
Nstat=3;
bpd=2;

srand=srand-diag(diag(srand));

k2=full(sum(srand));
k2_max=max(k2);

b2_max=1+floor(bpd.*log10(k2_max));
b1_max=b2_max;

n_1_2_sym=zeros(b1_max+1,b2_max+1);
binned_srand;

n_1_2_sym_orig=n_1_2;
sym_generate_srand;

binned_srand;

aver_n_1_2_sym=n_1_2;
aver_sq_n_1_2_sym=n_1_2.^2;

for k=2:Nstat;
   k
   sym_generate_srand;
   binned_srand;
   aver_n_1_2_sym=aver_n_1_2_sym+n_1_2;
   aver_sq_n_1_2_sym=aver_sq_n_1_2_sym+n_1_2.^2;
end;
aver_n_1_2_sym=aver_n_1_2_sym./Nstat;
aver_sq_n_1_2_sym=aver_sq_n_1_2_sym./Nstat;
err_n_1_2_sym=sqrt(aver_sq_n_1_2_sym-aver_n_1_2_sym.^2);


sym_ratio_1_2_sym=n_1_2_sym_orig./(aver_n_1_2_sym+0.0001.*(aver_n_1_2_sym==0));
dev_n_1_2_sym_orig=(n_1_2_sym_orig-aver_n_1_2_sym)./(err_n_1_2_sym+0.0001.*(aver_n_1_2_sym==0));


sym_ratio_1_2_sym(end,:)=sym_ratio_1_2_sym(end-1,:);
sym_ratio_1_2_sym(:,end)=sym_ratio_1_2_sym(:,end-1);
dev_n_1_2_sym_orig(end,:)=dev_n_1_2_sym_orig(end-1,:);
dev_n_1_2_sym_orig(:,end)=dev_n_1_2_sym_orig(:,end-1);

figure;  pcolor(sym_ratio_1_2_sym);  colorbar


shading interp; 
colorbar;

figure;  pcolor(dev_n_1_2_sym_orig);  



shading interp; 
colorbar;

num2str(sym_ratio_1_2_sym(1:end-1,1:end-1))
num2str(dev_n_1_2_sym_orig(1:end-1,1:end-1))

