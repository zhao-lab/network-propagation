%binned_srand
sa=srand;

k_out_a=full(sum(sa'));
k_in_a=full(sum(sa));

k_1=k_out_a;
k_2=k_in_a;


[i1,j1,v1]=find(sa);
E=length(i1);
n_1_2=zeros(b1_max+1,b2_max+1);
for i=1:E;
   kc1=k_1(i1(i));
   kc2=k_2(j1(i));
   if kc1.*kc2>0;
     b1=1+floor(bpd*log10(kc1));
     b2=1+floor(bpd*log10(kc2));
     n_1_2(b1,b2)=n_1_2(b1,b2)+v1(i);
   end;
end;
