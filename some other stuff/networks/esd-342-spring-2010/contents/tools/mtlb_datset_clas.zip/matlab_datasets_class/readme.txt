Note on ESD_342 data sets

bike.wk1 and karate.wk1 are adjacency matrices in Lotus123 wk1 format

Matlab can read them using wk1read('filename')

western_power_grid_reformatted2 is a node list in comma-delimited format.

Matlab can read it using csvread('filename') or dlmread('filename')
