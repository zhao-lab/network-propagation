% Checks whether a matrix is symmetric
% Gergana Bounova, November 2, 2005

function [issym] = issymmetric(mat)

% inputs: (square) matrix
% outputs: boolean variable, {0,1}

% check whether mat(i,j)=mat(j,i) for all i,j
issym = true; % default
n=length(mat);
for i=1:n
  for j=i+1:n
    if not(mat(i,j)==mat(j,i))
      issym = false;
      return
    end
  end
end