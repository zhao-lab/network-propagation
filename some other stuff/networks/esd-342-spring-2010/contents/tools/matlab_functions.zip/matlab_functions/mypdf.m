% custom pdf function
% Gergana Bounova, December 18, 2005

function [pdf_value] = mypdf(x)

% input: variable x
% output: probability that X=x, where X is a random variable from the mypdf
          % distribution
          
% this is an arbitrary function for now, 0<=pdf_value<=1
pdf_value = abs(x/(100+x));
%pdf_value = exp(-x);
%pdf_value = abs(1/x*exp(-x/100));