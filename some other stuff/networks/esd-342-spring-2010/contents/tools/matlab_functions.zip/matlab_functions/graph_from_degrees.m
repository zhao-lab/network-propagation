% Build a graph given a degree sequence
% Find a non-unique simple graph construction
% Dimitar Bounov, February 20, 2006

function [adj] = graph_from_degrees(degs)

% INPUTs: degree sequence vector, 1xn, 
% OUTPUTs: adj - adjacency matrix, nxn

%V={}
%  count=0;
%  S={v0,v1,v2...vn}
%  deg_sum=sum(v0,v1,...vn);
%  a=find_vertex_with_maximum_degree();
%  add_to_V ;count++;
%  // Part 1 
%  while (sum>0) and (count!=n) do
%    {
%    // The next lines find two vectors a and b with positive degrees, such that one is in V an the other is not
%    // and at least one has degree more than 1.If it cant find them it finds two vectors of degree 1 one inside V one outside V.
%    
%    a=find_vertice_positive_degree_more_than_1(V);
%    
%    if (a==NULL) a=find_vertice_positive_degree(V);
%    
%    b=find_vertice_positive_degree_more_than_1(outside of V);
%    
%    if (b==NULL) b=find_vertice_positive_degree(outside of V);
%    
%    add_to_V( b ) ;
%    S[a]--;
%    S[b]--;
%    count++;
%    sum=sum-2;
%    }
%  // Part 2
%  while (sum>0) do{
%  a=find_vertice_positive_degre(V);
%  b=NULL;
%  while (a!=b) do b=find_vertice_positive_degre(V); // Tova e s cel a da ne go svurzem sus sebe si
%  S[a]--;S[b]--;sum=sum-2;  
%  }


n = numel(degs); % number of nodes
adj = zeros(n);
Vo = []; % empty set
count = 0;
deg_sum = sum(degs);
if mod(deg_sum,2)==1
  'invalid degree sequence, sum has to be even';
  return
end
[maxd, max_deg_ind] = max(degs);
Vo = [Vo max_deg_ind];
V1 = setdiff([1:n],Vo); % set of remaining nodes

issmpl = false;
cnt = 0;

while not(issmpl)
  %'new'
  %cnt = cnt + 1
  rand('state',sum(100*clock)) 
  while not(issmpl)
    
    while not(isempty(V1)) & not(count==n) & deg_sum>0
  
      indVop1 = find(degs(Vo)>1);
      %[maxv,indVop1] = max(degs(Vo));
      if isempty(indVop1)
        indVop = find(degs(Vo)==1);
        a = Vo(indVop(1));
      else
	a = Vo(indVop1(ceil(rand*length(indVop1))));
	%a = Vo(indVop1(1));
      end
      indV1p1 = find(degs(V1)>1);
      %[maxv,indV1p1] = max(degs(V1));
      if isempty(indV1p1)
        indV1p = find(degs(V1)==1);
        b = V1(indV1p(1));
      else
	b = V1(indV1p1(ceil(rand*length(indV1p1))));
	%b = V1(indV1p1(1));
      end
      adj(a,b)=adj(a,b)+1; adj(b,a)=adj(b,a)+1;
      degs(a) = degs(a)-1; degs(b) = degs(b)-1;
      deg_sum = sum(degs);
      count = count + 1;
      Vo = [Vo b]; V1 = setdiff(V1,b);
  
    end
    
    issmpl = issimple(adj);


  end

  tic
  while deg_sum>0
    
    rand('state',sum(100*clock)) 
    %deg_sum
    %find(degs>0)
    %adj
    inda = find(degs(Vo)>0);
    a = Vo(inda(ceil(rand*length(inda))));
    indb = find(degs(Vo)>0);   
    b = Vo(indb(ceil(rand*length(indb))));

    if not(a==b) & adj(a,b)==0
      adj(a,b)=adj(a,b)+1; adj(b,a)=adj(b,a)+1; 
      degs(a) = degs(a)-1; degs(b) = degs(b)-1;
      deg_sum = sum(degs);
    end
    
    %issmpl = issimple(adj);
    
    if toc>10
      issmpl = false;
      break
    end
  end
  
end