% Converts an adjacency graph representation to a list
% (pointers) representation
% Gergana Bounova, October 3, 2005

function [str] = adj2str(adj)

% INPUT: an adjacency matrix, NxN, N - # of nodes

% OUTPUT: data structure with pointers to children

% N = length(adj); % number of nodes

for i=1:length(adj)
  str(i).child = find(adj(i,:)>0);
end