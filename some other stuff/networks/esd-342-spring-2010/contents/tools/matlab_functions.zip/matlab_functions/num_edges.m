% Returns the total number of edges given the adjacency matrix
% Gergana Bounova, February 19, 2006

function [m] = num_edges(adj)

% INPUTs: adj - adjacency matrix
% OUTPUTs: m - total number of edges/links

if isdirected(adj)
  m = sum(sum(adj)); return
elseif not(isdirected(adj))
  m = sum(sum(adj))/2; return
end